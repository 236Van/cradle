import express from 'express';
import Event from '../models/Event';

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const events = await Event.find().populate('createdBy', 'email');
    res.json(events);
  } catch (error) {
    res.status(500).json({ error: 'Something went wrong' });
  }
});

router.post('/', async (req, res) => {
  try {
    const { name, date, location, description, createdBy } = req.body;
    const event = new Event({ name, date, location, description, createdBy });
    await event.save();
    res.status(201).json(event);
  } catch (error) {
    res.status(500).json({ error: 'Something went wrong' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const event = await Event.findById(req.params.id).populate('createdBy', 'email');
    if (!event) {
      return res.status(404).json({ error: 'Event not found' });
    }
    res.json(event);
  } catch (error) {
    res.status(500).json({ error: 'Something went wrong' });
  }
});

export default router;