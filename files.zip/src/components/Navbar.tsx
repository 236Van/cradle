import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav style={{ backgroundColor: '#415092', padding: '1rem' }}>
      <Link to="/" style={{ color: 'white', marginRight: '1rem' }}>Home</Link>
      <Link to="/create-event" style={{ color: 'white', marginRight: '1rem' }}>Create Event</Link>
      <Link to="/profile" style={{ color: 'white', marginRight: '1rem' }}>Profile</Link>
      <Link to="/sign-in" style={{ color: 'white', marginRight: '1rem' }}>Sign In</Link>
      <Link to="/sign-up" style={{ color: 'white', marginRight: '1rem' }}>Sign Up</Link>
    </nav>
  );
};

export default Navbar;