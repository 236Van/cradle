import React from 'react';

const Home = () => {
  return (
    <div style={{ padding: '1rem' }}>
      <h1 style={{ color: '#415092' }}>Welcome to Cradle-Event</h1>
      <p>Discover events near you and join the fun!</p>
    </div>
  );
};

export default Home;