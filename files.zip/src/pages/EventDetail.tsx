import React from 'react';

const EventDetail = () => {
  return (
    <div style={{ padding: '1rem' }}>
      <h1 style={{ color: '#415092' }}>Event Detail</h1>
      <p>Details of the event will be shown here.</p>
    </div>
  );
};

export default EventDetail;