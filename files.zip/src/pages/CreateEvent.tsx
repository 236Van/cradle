import React from 'react';

const CreateEvent = () => {
  return (
    <div style={{ padding: '1rem' }}>
      <h1 style={{ color: '#415092' }}>Create Event</h1>
      <form>
        <div>
          <label>Event Name:</label>
          <input type="text" name="name" />
        </div>
        <div>
          <label>Date:</label>
          <input type="date" name="date" />
        </div>
        <div>
          <label>Location:</label>
          <input type="text" name="location" />
        </div>
        <div>
          <label>Description:</label>
          <textarea name="description"></textarea>
        </div>
        <button type="submit" style={{ backgroundColor: '#FF40EC', color: 'white' }}>Create Event</button>
      </form>
    </div>
  );
};

export default CreateEvent;