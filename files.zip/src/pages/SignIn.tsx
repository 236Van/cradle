import React from 'react';

const SignIn = () => {
  return (
    <div style={{ padding: '1rem' }}>
      <h1 style={{ color: '#415092' }}>Sign In</h1>
      <form>
        <div>
          <label>Email:</label>
          <input type="email" name="email" />
        </div>
        <div>
          <label>Password:</label>
          <input type="password" name="password" />
        </div>
        <button type="submit" style={{ backgroundColor: '#FF40EC', color: 'white' }}>Sign In</button>
      </form>
    </div>
  );
};

export default SignIn;