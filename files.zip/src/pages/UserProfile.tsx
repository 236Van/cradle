import React from 'react';

const UserProfile = () => {
  return (
    <div style={{ padding: '1rem' }}>
      <h1 style={{ color: '#415092' }}>User Profile</h1>
      <p>User information and events created by the user will be shown here.</p>
    </div>
  );
};

export default UserProfile;